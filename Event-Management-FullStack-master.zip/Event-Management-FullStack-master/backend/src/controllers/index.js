module.exports = {
    LoginController : require('./login-controllers'),
    RegisterController : require('./register-controllers'),
    EventController : require('./event-controllers'),
}